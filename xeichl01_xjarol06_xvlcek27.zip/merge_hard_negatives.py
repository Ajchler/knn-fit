import json

with open("evaluation-data/hard-negatives-alternatives.json", "r") as f:
    hards = json.load(f)

with open("evaluation-data/neg_exSets-scores-sorted04.json", "r") as f:
    hards_tonda = json.load(f)

with open("evaluation-data/neg_exSets-scores-sorted.json", "r") as f:
    hards_tonda2 = json.load(f)

new_dict = {}

for textid in hards:
    text = hards_tonda2[textid]["text"]
    new_dict[text] = {}
    topics = [foo["topic"] for foo in hards_tonda2[textid]["potential_negatives_all"]][:5]
    new_dict[text]["neg_exSets-scores-sorted"] = topics
    topics = [foo["topic"] for foo in hards_tonda[textid]["potential_negatives_all"]]
    new_dict[text]["neg_exSets-scores-sorted04"] = topics
    new_dict[text]["hard-negatives-alternatives"] = hards[textid]

with open("evaluation-data/merged_hard_negatives.json", "w") as f:
    json.dump(new_dict, f, indent=4, ensure_ascii=False)